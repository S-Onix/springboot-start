package com.example.interceptor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InterceptorApplicationTests {

	@Test
	void contextLoads() {
	}

}
