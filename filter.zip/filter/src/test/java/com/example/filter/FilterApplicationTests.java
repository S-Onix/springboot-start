package com.example.filter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FilterApplicationTests {

	@Test
	void contextLoads() {
	}

}
