package com.example.springcurltest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCurlTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
