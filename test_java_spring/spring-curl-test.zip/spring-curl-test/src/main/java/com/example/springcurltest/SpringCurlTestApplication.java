package com.example.springcurltest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCurlTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringCurlTestApplication.class, args);
	}

}
